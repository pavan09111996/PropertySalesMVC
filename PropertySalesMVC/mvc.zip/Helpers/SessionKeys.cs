﻿namespace PropertySalesMVC.Helpers
{
    public static class SessionKeys
    {
        public const string AdminId = "AdminId";
        public const string AdminName = "AdminName";
        public const string IsAdminLoggedIn = "IsAdminLoggedIn";
    }
}
